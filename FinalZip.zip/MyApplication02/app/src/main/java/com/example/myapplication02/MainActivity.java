package com.example.myapplication02;

import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DBHelper myDb;
    EditText editFullName , editAddress , editContactNumber , editOrderNotes, editTextId ;
    Button btnViewAll;
    Button btnViewUpdate;
    Button btnDelete;
    Button Add;

    //@SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        myDb = new DBHelper(this);

        editFullName = findViewById(R.id.editTextTextPersonName2);
        editAddress = findViewById(R.id.editTextTextPostalAddress);
        editContactNumber = findViewById(R.id.editTextPhone);
        editOrderNotes = findViewById(R.id.editTextTextPostalAddress2);
        Add = findViewById(R.id.btnAddFood);

        //editTextId = findViewById(R.id.button8);
        btnViewUpdate = findViewById(R.id.button9);
        btnDelete = findViewById(R.id.button10);
        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDetails();
            }
        });

    }
    public void addDetails(){
       boolean res = myDb.insertData(editFullName.getText().toString().trim(),editAddress.getText().toString().trim(),
                editContactNumber.getText().toString().trim(),editOrderNotes.getText().toString().trim());

       if(res == true){
           Toast.makeText(this,"Successfully inserted!",Toast.LENGTH_SHORT).show();
       }else{
           Toast.makeText(this,"Unsuccessful!",Toast.LENGTH_SHORT).show();
       }
    }
    public void Deletedata(){
        btnDelete.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        Integer deleteRows = myDb.deleteData(editTextId.getText().toString());
                        if(deleteRows>0)
                            Toast.makeText(MainActivity.this,"Data Deleted",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Please insert a valid ID",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }
    public void UpdateData(){
        btnViewUpdate.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        String sID = editTextId.getText().toString();
                        if (sID.matches("")) {
                            Toast.makeText(MainActivity.this, "Please insert a valid ID", Toast.LENGTH_SHORT).show();
                            return;}
                        String sUsername = editFullName.getText().toString();
                        if (sUsername.matches("")) {
                            Toast.makeText(MainActivity.this, "You did not enter a username", Toast.LENGTH_SHORT).show();
                            return;}
                        String sVehicleNumber = editAddress.getText().toString();
                        if (sUsername.matches("")) {
                            Toast.makeText(MainActivity.this, "You did not enter vehcile Number", Toast.LENGTH_SHORT).show();
                            return;}
                        String sMobileNumber = editContactNumber.getText().toString();
                        if (sUsername.matches("")) {
                            Toast.makeText(MainActivity.this, "You did not enter a mobile", Toast.LENGTH_SHORT).show();
                            return;}
                        String sService = editOrderNotes.getText().toString();
                        if (sUsername.matches("")) {
                            Toast.makeText(MainActivity.this, "You did not enter service", Toast.LENGTH_SHORT).show();
                            return;}
                        boolean isUpdate = myDb.updateData(editTextId.getText().toString(), editFullName.getText().toString(),
                                editAddress.getText().toString(),
                                editContactNumber.getText().toString  (),
                                editOrderNotes.getText().toString());
                        if(isUpdate == true)
                            Toast.makeText(MainActivity.this,"Data Updated",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Data not Updated",Toast.LENGTH_LONG).show();

                    }


                }
        );
    }

    public void viewAll() {
        btnViewAll.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                        if (res.getCount() == 0) {
                            //show message
                            showMessage("Error", "Nothing found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Food Id :" + res.getString(0) + "\n");
                            buffer.append("Full Name :" + res.getString(1) + "\n");
                            buffer.append("Address :" + res.getString(2) + "\n");
                            buffer.append("Contact Number :" + res.getString(3) + "\n");
                            buffer.append("Order Notes:" + res.getString(4) + "\n");
                        }
                        //getalldata
                        showMessage("Customer Services", buffer.toString());
                    }

                }
        );

    }

    public void showMessage(String title , String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}


