package com.example.myapplication02;


import android.content.ContentValues;
import android.content.Context;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="Manuja.db";
    public static final String TABLE_NAME="Food";
    public static final String COL_1="FoodId";
    public static final String COL_2="FullName";
    public static final String COL_3="Address";
    public static final String COL_4="Contact Number";
    public static final String COL_5="Order Notes";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getReadableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " ( FoodId INTEGER PRIMARY KEY AUTOINCREMENT , FullName TEXT , Address TEXT , ContactNumber INTEGER , OrderNotes TEXT )" );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }
    public boolean insertData(String FullName , String Address , String ContactNumber, String OrderNotes ){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,FullName);
        contentValues.put(COL_3,Address);
        contentValues.put(COL_4,ContactNumber);
        contentValues.put(COL_5,OrderNotes);
        long result = db.insert(TABLE_NAME,null , contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }
    public boolean updateData(String FoodId , String FullName , String Address,String ContactNumber , String OrderNotes){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1,FoodId);
        contentValues.put(COL_2,FullName);
        contentValues.put(COL_3,Address);
        contentValues.put(COL_4,ContactNumber);
        contentValues.put(COL_5,OrderNotes);
        db.update(TABLE_NAME,contentValues,"id = ?",new String[] { FoodId });
        return true;

    }
    public Integer deleteData(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME,"id = ?",new String[]{id});
    }
}
